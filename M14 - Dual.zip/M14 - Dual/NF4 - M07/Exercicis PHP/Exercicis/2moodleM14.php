<html>
	<head>
		<title>2moodle.php</title>
	</head>
	<body>
		<?php
		//Si no has entrat correctament la variable a la URL mostra que NO HAS ENTRAT CAP NUMERO
			if (!isset($_GET['numeros'])){
				echo "No has entrat cap numero";
			}
		//Si els has entrat correctament, 
			else {
				//Si els has ntrat correctament, els ordena a de froma ascendent
				$nums=$_GET['numeros'];
				$valors=explode(',',$nums);
				echo "<u>";
				echo "<strong>";
				echo "NÚMEROS ENTRATS ORDENATS";
				echo "</strong>";
				echo "</u>";
				echo "<br>";
				echo "<br>";
		        sort($valors);
				foreach ($valors as $value){
					echo $value;
					echo " ";
				}
			}
		?>
	</body>
</html>