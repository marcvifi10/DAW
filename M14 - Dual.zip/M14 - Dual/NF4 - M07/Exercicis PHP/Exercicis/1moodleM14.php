<html>
	<head>
		<title>1moodle.php</title>
	</head>
	<body>
		<?php
		//Declarem les variables
			$beguda1="Coca-Cola";
			$beguda1="Café";
			$beguda1="Cervessa";
			$preu1="1.10";
			$preu2="1.00";
			$preu3="0.90";
			$suma=$preu1+$preu2+$preu3;
			$iva=$suma*0.21;
			$total=$suma+$iva;
			
		//Mostrem per pantalla els preus
			echo "Coca-Cola x 1 = $preu1";
			echo "<br>";
			echo "Café x 1 = $preu2";
			echo "<br>";
			echo "Cervessa x 1 = $preu3";
			echo "<br>";
			echo "IVA = $iva";
			echo "<br>";
			echo "TOTAL = $total";
			echo "<br>";
		?>
	</body>
</html>