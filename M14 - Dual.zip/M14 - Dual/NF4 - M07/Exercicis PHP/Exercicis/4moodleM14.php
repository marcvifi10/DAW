<?php
	//Iniciem la sessió
	session_start();

	//Si no existeix la sessió el nombre d'intents l'igualem a 0
	if(!isset($_SESSION['intents']))
	{
		$_SESSION['intents']=0;
	}
	//Si existeix la variable de sessió augmentem al nombre d'intents	
	else
	{
		$_SESSION['intents']+=1;
	}
?>
<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8">
		<title>4moodleM14.php</title>
	</head>
	<body>
		<?php
			//Si no existeix la variable de sessió 
			if(!isset($_SESSION['sessio']))
			{
				//Generem una variable de tipus data
				$temps = getdate();
				//Igualem a una variable al nombre de segons ja que el getdate ens retorna un array, i només ens interessen els segons
				$segons_abans = $temps['seconds'];
				//Igualem a la variable de sessió els segons de la variable anterior
				$_SESSION['sessio'] = $segons_abans;
			}
			//Si exiteix la variable de sessió fem el següent
			else{
				//Si no existeix la variable de sessio, que està per comprovar la diferencia de temps 
				if(!isset($_SESSION['sessio2'])) 
				{
					//Generem una variable de tipus data
					$segons1 = getdate();
					//Igualem a una variable al nombre de segons ja que el getdate ens retorna un array, i només ens interessen els segons
					$segons_despres = $segons1['seconds'];
					//Igualem a la variable de sessió els segons de la varaible anterior
					$_SESSION['sessio2'] = $segons_despres;
					//A la variable de sessio calculem la diferencia de segons de les dues variables de sessió 
					$resultat=abs($_SESSION['segons_despres']-$_SESSION['segons']);
					//Si el nombre de segons de la variable de sessió resultat és igual al de la variable de sessió random s'executa la següent condició
					if ($resultat==$_SESSION['random'])
					{
						//Si es compleix l'anterior condició s'executarà el següent
						echo "<br>";
						echo "<br>";
						echo "Has refrescat la pàgina correctament";
						echo "<br>";
						echo "<br>";
						$_SESSION['intents']=0;
					}
					//Si el nombre de segons de la variable de sessió resultat no és igual al de la variable de sessió random s'executa el següent
					echo "<br>";
					echo "<br>";
					echo "Has tardat ".$resultat." segons";
					echo "<br>";
					echo "<br>";
					echo "Intents: ".$_SESSION['intents'];
					echo "<br>";
					echo "<br>";
 				}
				//Si existeix la variable de sessió sessio2 s'executarà el següent
				else
				{
					//Maxaquem la variable de sessió
					$_SESSION['sessio'] = $_SESSION['sessio2'];
					//Creem una variable de tipus date
					$temps = getdate();
					//Igualem a la variable de sessió els segons de la varaible anterior
					$_SESSION['sessio2']=$temps['seconds'];
					//A la variable de sessio calculem la diferencia de segons de les dues variables de sessió 
					$resultat=abs($_SESSION['sessio2']-$_SESSION['sessio']);
					//Si el nombre de segons de la variable de sessió resultat és igual al de la variable de sessió random s'executa la següent condició
					if ($resultat==$_SESSION['random'])
					{
						//Si es compleix l'anterior condició s'executa el següent
						echo "<br>";
						echo "<br>";
						echo "Has refrescat la pàgina correctament";
						echo "<br>";
						echo "<br>";
						echo "Ho has aconseguit amb ".$_SESSION['intents']." intents.";
						$_SESSION['intents']=0;
					}
					//Si el nombre de segons de la variable de sessió resultat no és igual al de la variable de sessió random s'executa el següent
					echo "<br>";
					echo "<br>";
					echo "Has tardat ".$resultat." segons";
					echo "<br>";
					echo "<br>";
					echo "Intents: ".$_SESSION['intents'];
					echo "<br>";
					echo "<br>";
				}
			}
			//Creem una variable on hi guardem un nombre aleatori entre 1 i 9
			$random=rand(1,9);
			//Creem una variable de sessió, de la variable de sessió anterior
			$_SESSION['random']=$random;
			//Sempre mostrarà per pantalla el següent
			echo "<br>";
			echo "<br>";
			echo "Fes clic sobre F5 al cap de ".$random." segons.";
			echo "";
			echo "<br>";
			echo "<br>";
		?>
	</body>
</html>