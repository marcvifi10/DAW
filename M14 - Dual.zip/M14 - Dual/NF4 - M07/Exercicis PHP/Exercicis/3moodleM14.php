<html>
	<head>
		<title>3moodleM14.php</title>
	</head>
	<body>
		<?php
		//Declarem una funció on validarà l'extensió del nom de l'arxiu entrat per la URL
			function extensio(){
				//Si no has entrat correctament el nom de la variable, mostrarà el següent
				if (!isset($_GET['foto'])){
					echo "No has entrat cap nom de cap foto";
				}
				//Si ho has entrat correctament
				else {
					$foto=$_GET['foto'];
					$nombre=explode('.',$foto);
					//Si té una de les següents extensions mostrarà que és VÀLID
					switch ($nombre[1]){
						case 'jpg': case 'png': case 'bmp': case 'gif':
							echo "<strong>";
							echo "<u>";
							echo "EL FITXER ÉS VÀLID!!!";
							echo "</u>";
							echo "</strong>";
							echo "<br>";
							echo "<br>";
							echo 'Té la extensió que li pertoca.';
						break;
						//Aquesta opció que mostrarà que l'arxiu no és vàlid, perquè no té l'extensió corresponent
						default:
							echo "<strong>";
							echo "<u>";
							echo "EL FITXER NO ÉS VÀLID!!!";
							echo "</u>";
							echo "</strong>";
							echo "<br>";
							echo "<br>";
							echo 'El fitxer no té la extensió corresponent!!!';
						break;
					}
				}
			}
			//Cridem a la funció anterior
			extensio();
		?>
	</body>
</html>