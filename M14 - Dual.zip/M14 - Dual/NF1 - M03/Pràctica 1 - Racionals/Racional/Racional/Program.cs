﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Racional
{
    class Program
    {
        static void Main(string[] args)
        {
            int opcio;
            do
            {
                Menu();
                opcio = Convert.ToInt32(Console.ReadLine());
                switch (opcio)
                {
                    case 1:
                        Console.Clear();
                        MostrarMenuMetodes();
                        int opcioMetodes = Convert.ToInt32(Console.ReadLine());
                        switch (opcioMetodes)
                        {
                            case 1:
                                Racional n1, n2, n3;
                                int num1, num2, den1, den2, res;
                                Console.WriteLine("Entra el numerador del primer Racional");
                                num1 = Convert.ToInt32(Console.ReadLine());
                                Console.WriteLine("Entra el denominador del primer Racional; !No pot ser 0!");
                                den1 = Convert.ToInt32(Console.ReadLine());
                                Console.WriteLine("Entra el numerador del segon Racional");
                                num2 = Convert.ToInt32(Console.ReadLine());
                                Console.WriteLine("Entra el denominador del segon Racional; !No pot ser 0!");
                                den2 = Convert.ToInt32(Console.ReadLine());
                                n1 = new Racional(num1, den1);
                                n2 = new Racional(num2, den2);
                                n3 = n1.Suma(n2);
                                MostrarMenuNormalitzar();
                                res = Convert.ToInt32(Console.ReadLine());
                                n3.Mostra(res);
                                break;

                            case 2:
                                Console.WriteLine("Entra el numerador del primer Racional");
                                num1 = Convert.ToInt32(Console.ReadLine());
                                Console.WriteLine("Entra el denominador del primer Racional; !No pot ser 0!");
                                den1 = Convert.ToInt32(Console.ReadLine());
                                Console.WriteLine("Entra el numerador del segon Racional");
                                num2 = Convert.ToInt32(Console.ReadLine());
                                Console.WriteLine("Entra el denominador del segon Racional; !No pot ser 0!");
                                den2 = Convert.ToInt32(Console.ReadLine());
                                n1 = new Racional(num1, den1);
                                n2 = new Racional(num2, den2);
                                n3 = n1.Resta(n2);
                                MostrarMenuNormalitzar();
                                res = Convert.ToInt32(Console.ReadLine());
                                n3.Mostra(res);
                                break;

                            case 3:
                                Console.WriteLine("Entra el numerador del primer Racional");
                                num1 = Convert.ToInt32(Console.ReadLine());
                                Console.WriteLine("Entra el denominador del primer Racional; !No pot ser 0!");
                                den1 = Convert.ToInt32(Console.ReadLine());
                                Console.WriteLine("Entra el numerador del segon Racional");
                                num2 = Convert.ToInt32(Console.ReadLine());
                                Console.WriteLine("Entra el denominador del segon Racional; !No pot ser 0!");
                                den2 = Convert.ToInt32(Console.ReadLine());
                                n1 = new Racional(num1, den1);
                                n2 = new Racional(num2, den2);
                                n3 = n1.Multiplicacio(n2);
                                MostrarMenuNormalitzar();
                                res = Convert.ToInt32(Console.ReadLine());
                                n3.Mostra(res);
                                break;

                            case 4:
                                Console.WriteLine("Entra el numerador del primer Racional");
                                num1 = Convert.ToInt32(Console.ReadLine());
                                Console.WriteLine("Entra el denominador del primer Racional; !No pot ser 0!");
                                den1 = Convert.ToInt32(Console.ReadLine());
                                Console.WriteLine("Entra el numerador del segon Racional");
                                num2 = Convert.ToInt32(Console.ReadLine());
                                Console.WriteLine("Entra el denominador del segon Racional; !No pot ser 0!");
                                den2 = Convert.ToInt32(Console.ReadLine());
                                n1 = new Racional(num1, den1);
                                n2 = new Racional(num2, den2);
                                n3 = n1.Divisio(n2);
                                MostrarMenuNormalitzar();
                                res = Convert.ToInt32(Console.ReadLine());
                                n3.Mostra(res);
                                break;

                            case 0:
                                break;

                        }
                        break;
                    case 2:
                        int num, den, resultat;
                        Racional racional;
                        Console.WriteLine("Entra el numerador del primer nombre Racional");
                        num = Convert.ToInt32(Console.ReadLine());
                        Console.WriteLine("Entra el denominador del primer nombre Racional. !No pot ser 0!");
                        den = Convert.ToInt32(Console.ReadLine());
                        racional = new Racional(num, den);
                        resultat = Convert.ToInt32(Console.ReadLine());
                        racional.Mostra();
                        break;

                    case 3:
                        Console.Clear();
                        MostrarMenuOperands();
                        int opcioOperands = Convert.ToInt32(Console.ReadLine());
                        switch (opcioOperands)
                        {
                            case 1:
                                int num1, den1, num2, den2, res;
                                Racional n1, n2, n3;
                                Console.WriteLine("Entra el numerador del primer nombre Racional");
                                num1 = Convert.ToInt32(Console.ReadLine());
                                Console.WriteLine("Entra el denominador del primer nombre Racional. !No pot ser 0!");
                                den1 = Convert.ToInt32(Console.ReadLine());
                                Console.WriteLine("Entra el numerador del segon nombre Racional");
                                num2 = Convert.ToInt32(Console.ReadLine());
                                Console.WriteLine("Entra el denominador del segon nombre Racional. !No pot ser 0!");
                                den2 = Convert.ToInt32(Console.ReadLine());
                                n1 = new Racional(num1, den1);
                                n2 = new Racional(num2, den2);
                                n3 = new Racional();

                                n3 = n1.Suma(n2);
                                MostrarMenuNormalitzar();
                                res = Convert.ToInt32(Console.ReadLine());
                                n3.Mostra(res);
                                break;

                            case 2:
                                Console.WriteLine("Entra el numerador del primer Racional");
                                num1 = Convert.ToInt32(Console.ReadLine());
                                Console.WriteLine("Entra el denominador del primer Racional; !No pot ser 0!");
                                den1 = Convert.ToInt32(Console.ReadLine());
                                Console.WriteLine("Entra el numerador del segon Racional");
                                num2 = Convert.ToInt32(Console.ReadLine());
                                Console.WriteLine("Entra el denominador del segon Racional; !No pot ser 0!");
                                den2 = Convert.ToInt32(Console.ReadLine());
                                n1 = new Racional(num1, den1);
                                n2 = new Racional(num2, den2);
                                n3 = n1.Resta(n2);
                                MostrarMenuNormalitzar();
                                res = Convert.ToInt32(Console.ReadLine());
                                n3.Mostra(res);
                                break;

                            case 3:
                                Console.WriteLine("Entra el numerador del primer Racional");
                                num1 = Convert.ToInt32(Console.ReadLine());
                                Console.WriteLine("Entra el denominador del primer Racional; !No pot ser 0!");
                                den1 = Convert.ToInt32(Console.ReadLine());
                                Console.WriteLine("Entra el numerador del segon Racional");
                                num2 = Convert.ToInt32(Console.ReadLine());
                                Console.WriteLine("Entra el denominador del segon Racional; !No pot ser 0!");
                                den2 = Convert.ToInt32(Console.ReadLine());
                                n1 = new Racional(num1, den1);
                                n2 = new Racional(num2, den2);
                                n3 = n1.Multiplicacio(n2);
                                MostrarMenuNormalitzar();
                                res = Convert.ToInt32(Console.ReadLine());
                                n3.Mostra(res);
                                break;

                            case 4:
                                Console.WriteLine("Entra el numerador del primer Racional");
                                num1 = Convert.ToInt32(Console.ReadLine());
                                Console.WriteLine("Entra el denominador del primer Racional; !No pot ser 0!");
                                den1 = Convert.ToInt32(Console.ReadLine());
                                Console.WriteLine("Entra el numerador del segon Racional");
                                num2 = Convert.ToInt32(Console.ReadLine());
                                Console.WriteLine("Entra el denominador del segon Racional; !No pot ser 0!");
                                den2 = Convert.ToInt32(Console.ReadLine());
                                n1 = new Racional(num1, den1);
                                n2 = new Racional(num2, den2);
                                n3 = n1.Divisio(n2);
                                MostrarMenuNormalitzar();
                                res = Convert.ToInt32(Console.ReadLine());
                                n3.Mostra(res);
                                break;

                            case 5:
                                Console.WriteLine("Entra el numerador del primer nombre Racional");
                                num1 = Convert.ToInt32(Console.ReadLine());
                                Console.WriteLine("Entra el denominador del primer nombre Racional. !No pot ser 0!");
                                den1 = Convert.ToInt32(Console.ReadLine());
                                Console.WriteLine("Entra el numerador del segon nombre Racional");
                                num2 = Convert.ToInt32(Console.ReadLine());
                                Console.WriteLine("Entra el denominador del segon nombre Racional !No pot ser 0!");
                                den2 = Convert.ToInt32(Console.ReadLine());
                                n1 = new Racional(num1, den1);
                                n2 = new Racional(num2, den2);
                                if (n1 == n2)
                                {
                                    Console.WriteLine("Els dos nombres racionals són iguals.");
                                }
                                else
                                {
                                    Console.WriteLine("Els dos nombres racionals són diferents.");
                                }
                                break;

                            case 6:
                                Console.WriteLine("Entra el numerador del primer nombre Racional");
                                num1 = Convert.ToInt32(Console.ReadLine());
                                Console.WriteLine("Entra el denominador del primer nombre Racional. !No pot ser 0!");
                                den1 = Convert.ToInt32(Console.ReadLine());
                                Console.WriteLine("Entra el numerador del segon nombre Racional");
                                num2 = Convert.ToInt32(Console.ReadLine());
                                Console.WriteLine("Entra el denominador del segon nombre Racional !No pot ser 0!");
                                den2 = Convert.ToInt32(Console.ReadLine());
                                n1 = new Racional(num1, den1);
                                n2 = new Racional(num2, den2);
                                if (n1 != n2)
                                {
                                    Console.WriteLine("Els dos nombres racionals són diferents.");
                                }
                                else
                                {
                                    Console.WriteLine("Els dos nombres racionals són iguals.");
                                }
                                break;

                            case 7:
                                bool mes_gran;
                                Console.WriteLine("Entra el numerador del primer nombre Racional");
                                num1 = Convert.ToInt32(Console.ReadLine());
                                Console.WriteLine("Entra el denominador del primer nombre Racional. !No pot ser 0!");
                                den1 = Convert.ToInt32(Console.ReadLine());
                                Console.WriteLine("Entra el numerador del segon nombre Racional");
                                num2 = Convert.ToInt32(Console.ReadLine());
                                Console.WriteLine("Entra el denominador del segon nombre Racional. !No pot ser 0!");
                                den2 = Convert.ToInt32(Console.ReadLine());
                                n1 = new Racional(num1, den1);
                                n2 = new Racional(num2, den2);
                                mes_gran = n1 < n2;
                                if (mes_gran)
                                {
                                    Console.WriteLine("El primer nombre racional és més petit que el segon.");
                                }
                                else
                                {
                                    Console.WriteLine("El primer nombre racional és més gran que el segon.");
                                }
                                break;

                            case 8:
                                bool mes_petit;
                                Console.WriteLine("Entra el numerador del primer nombre Racional");
                                num1 = Convert.ToInt32(Console.ReadLine());
                                Console.WriteLine("Entra el denominador del primer nombre Racional. !No pot ser 0!");
                                den1 = Convert.ToInt32(Console.ReadLine());
                                Console.WriteLine("Entra el numerador del segon nombre Racional");
                                num2 = Convert.ToInt32(Console.ReadLine());
                                Console.WriteLine("Entra el denominador del segon nombre Racional. !No pot ser 0!");
                                den2 = Convert.ToInt32(Console.ReadLine());
                                n1 = new Racional(num1, den1);
                                n2 = new Racional(num2, den2);
                                mes_petit = n1 > n2;
                                if (mes_petit)
                                {
                                    Console.WriteLine("El primer nombre racional és més gran que el segon.");
                                }
                                else
                                {
                                    Console.WriteLine("El primer nombre racional és més petit que el segon.");
                                }
                                break;
                            case 9:
                                bool mes_gran_igual;
                                Console.WriteLine("Entra el numerador del primer nombre Racional");
                                num1 = Convert.ToInt32(Console.ReadLine());
                                Console.WriteLine("Entra el denominador del primer nombre Racional. !No pot ser 0!");
                                den1 = Convert.ToInt32(Console.ReadLine());
                                Console.WriteLine("Entra el numerador del segon nombre Racional");
                                num2 = Convert.ToInt32(Console.ReadLine());
                                Console.WriteLine("Entra el denominador del segon nombre Racional. !No pot ser 0!");
                                den2 = Convert.ToInt32(Console.ReadLine());
                                n1 = new Racional(num1, den1);
                                n2 = new Racional(num2, den2);
                                mes_gran_igual = n1 <= n2;
                                if (mes_gran_igual)
                                {
                                    Console.WriteLine("El primer nombre racional és més gran o igual que el segon.");
                                }
                                else
                                {
                                    Console.WriteLine("El primer nombre racional és més petit que el segon.");
                                }
                                break;

                            case 10:
                                bool mes_petit_igual;
                                Console.WriteLine("Entra el numerador del primer nombre Racional");
                                num1 = Convert.ToInt32(Console.ReadLine());
                                Console.WriteLine("Entra el denominador del primer nombre Racional. !No pot ser 0!");
                                den1 = Convert.ToInt32(Console.ReadLine());
                                Console.WriteLine("Entra el numerador del segon nombre Racional");
                                num2 = Convert.ToInt32(Console.ReadLine());
                                Console.WriteLine("Entra el denominador del segon nombre Racional. !No pot ser 0!");
                                den2 = Convert.ToInt32(Console.ReadLine());
                                n1 = new Racional(num1, den1);
                                n2 = new Racional(num2, den2);
                                mes_petit_igual = n1 >= n2;
                                if (mes_petit_igual)
                                {
                                    Console.WriteLine("El primer nombre racional és més petit o igual que el segon.");
                                }
                                else
                                {
                                    Console.WriteLine("El primer nombre racional és més gran que el segon.");
                                }
                                break;

                            case 11:
                                int residu;
                                Console.WriteLine("Entra el numerador del primer nombre Racional");
                                num1 = Convert.ToInt32(Console.ReadLine());
                                Console.WriteLine("Entra el denominador del primer nombre Racional. !No pot ser 0!");
                                den1 = Convert.ToInt32(Console.ReadLine());
                                Console.WriteLine("Entra el numerador del segon nombre Racional");
                                num2 = Convert.ToInt32(Console.ReadLine());
                                Console.WriteLine("Entra el denominador del segon nombre Racional. !No pot ser 0!");
                                den2 = Convert.ToInt32(Console.ReadLine());
                                n1 = new Racional(num1, den1);
                                n2 = new Racional(num2, den2);
                                residu = Convert.ToInt32(Console.ReadLine());
                                residu = n1 % n2;
                                Console.WriteLine("El residu de la divisió entre els dos nombres racionals anteriors entrats per teclat és " + residu + ".");
                                break;

                            case 12:
                                Console.WriteLine("Entra el numerador del nombre Racional");
                                num1 = Convert.ToInt32(Console.ReadLine());
                                Console.WriteLine("Entra el denominador del nombre Racional. !No pot ser 0!");
                                den1 = Convert.ToInt32(Console.ReadLine());
                                Racional R1 = new Racional(num1, den1);
                                R1++;
                                R1.Mostra(2);
                                R1.Mostra(1);
                                break;

                            case 13:
                                Console.WriteLine("Entra el numerador del nombre Racional");
                                num1 = Convert.ToInt32(Console.ReadLine());
                                Console.WriteLine("Entra el denominador del nombre Racional. !No pot ser 0!");
                                den1 = Convert.ToInt32(Console.ReadLine());
                                Racional R2= new Racional(num1, den1);
                                R2--;
                                R2.Mostra(2);
                                R2.Mostra(1);
                                break;
                        }
                        break;
                    case 4:
                        Racional contador = new Racional();
                         int nRacionals = contador.Contador;
                        Console.WriteLine("S'han introduït " + nRacionals + " nombres racionals en aquesta execució del programa.");
                        break;
                }
            } while (opcio != 0);
        }
        public static void Menu()
        {
            Console.WriteLine("===================================================================");
            Console.WriteLine("                           MENÚ PRINCIPAL                          ");
            Console.WriteLine("===================================================================");
            Console.WriteLine("-------------------------------------------------------------------");
            Console.WriteLine("                          Escull una opció:                        ");
            Console.WriteLine("-------------------------------------------------------------------");
            Console.WriteLine("    1. Operacions amb mètodes");
            Console.WriteLine("    2. Mostra Racional");
            Console.WriteLine("    3. Operacions amb operands");
            Console.WriteLine("    4. Quantitat de nombres racionals introduïts per teclat ");
            Console.WriteLine("    0. Sortir");
            Console.WriteLine("-------------------------------------------------------------------");
            Console.WriteLine(" Quina opció vols triar? ");
        }
        public static void MostrarMenuMetodes()
        {
            Console.WriteLine("=======================================");
            Console.WriteLine("  MENÚ DE LES OPERACIONS AMB MÈTODES:  ");
            Console.WriteLine("=======================================");
            Console.WriteLine("---------------------------------------");
            Console.WriteLine("           Escull una opció:           ");
            Console.WriteLine("---------------------------------------");
            Console.WriteLine(" 1. Suma");
            Console.WriteLine(" 2. Resta");
            Console.WriteLine(" 3. Multiplicació");
            Console.WriteLine(" 4. Divisió");
            Console.WriteLine(" 0. Sortir");
            Console.WriteLine("---------------------------------------");
            Console.WriteLine(" Quina opció vols triar?");
        }
        public static void MostrarMenuOperands()
        {
            Console.WriteLine("==========================================");
            Console.WriteLine("   MENÚ DE LES OPERACIONS AMB OPERANDS:   ");
            Console.WriteLine("==========================================");
            Console.WriteLine("------------------------------------------");
            Console.WriteLine("             Escull una opció:            ");
            Console.WriteLine("------------------------------------------");
            Console.WriteLine(" 1. R1 + R2");
            Console.WriteLine(" 2. R1 - R2");
            Console.WriteLine(" 3. R1 * R2");
            Console.WriteLine(" 4. R1 / R2");
            Console.WriteLine(" 5. R1 == R2");
            Console.WriteLine(" 6. R1 != R2");
            Console.WriteLine(" 7. R1 > R2");
            Console.WriteLine(" 8. R1 < R2");
            Console.WriteLine(" 9. R1 <= R2");
            Console.WriteLine(" 10. R1 >= R2");
            Console.WriteLine(" 11. R1 % R2");
            Console.WriteLine(" 12. R1++");
            Console.WriteLine(" 13. R1--");
            Console.WriteLine(" 0. Sortir");
            Console.WriteLine("------------------------------------------");
            Console.WriteLine(" Quina opció vols triar?");
        }
        public static void MostrarMenuNormalitzar()
        {
            Console.WriteLine("-------------------------------------------");
            Console.WriteLine("   Vols mostrar el resultat normalitzat?   ");
            Console.WriteLine("-------------------------------------------");
            Console.WriteLine(" 1. Si");
            Console.WriteLine(" 2. No");
            Console.WriteLine("-------------------------------------------");
            Console.WriteLine(" Quina opció vols triar?");
        }
    }
}

