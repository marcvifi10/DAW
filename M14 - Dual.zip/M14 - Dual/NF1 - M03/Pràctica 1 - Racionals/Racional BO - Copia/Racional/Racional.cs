﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Racional
{
    class Racional
    {
        private static int contador = 0;
        int num;
        int den;

        public Racional()
        {
            num = 1;
            den = 1;
            contador++;
        }
        public int Contador
        {
            get
            {
                return contador;
            }
      
        }

        public Racional(int a, int b)
        {
            num = a;
            den = b;
            contador++;
        }

        public Racional(Racional n1)
        {
            this.num = n1.num;
            this.den = n1.den;
            contador++;
        }

        public int Num
        {
            get
            {
                return num;
            }
            set
            {
                num = value;
            }
        }

        public int Den
        {
            get { return den; }
            set { den = value; }
        }

        public Racional Suma(Racional fraccio)
        {
            Racional R3 = new Racional();
            R3.num = this.num * fraccio.den + this.den * fraccio.num;
            R3.den = this.den * fraccio.den;
            if (R3.den == 0)
            {
                Console.WriteLine("No es pot calcular perquè el denominador és igual a 0");
            }
            //return R3;
        }

        //public Racional Resta(Racional fraccio)
        //{
           // Racional R3 = new Racional();

           // R3.num = this.num * fraccio.den - this.den * fraccio.num;
            //R3.den = this.num * fraccio.den;
            //if (R3.den == 0)
           // {
           //     Console.WriteLine("No es pot calcular perquè el denominador és igual a 0");
          //  }
          //  return R3;
       // }

        public Racional Multiplicacio(Racional fraccio)
        {
            Racional R3 = new Racional();
            R3.num = this.num * fraccio.num;
            R3.den = this.den * fraccio.den;
            if (R3.den == 0)
            {
                Console.WriteLine("No es pot calcular perquè el denominador és igual a 0");
            }
            return R3;
        }

        public Racional Divisio(Racional fraccio)
        {
            Racional R3 = new Racional();
            R3.num = this.num * fraccio.den;
            R3.den = this.den * fraccio.num;
            if (R3.den == 0)
            {
                Console.WriteLine("No es pot calcular perquè el denominador és igual a 0");
            }
            return R3;
        }

        //private int MCD(Racional fraccio)
        //{
           // int a = Math.Abs(num);
           // int b = Math.Abs(den);
           // if (b == 0)
           // {
               // return a;
           // }
           // int residu;
           // while (b != 0)
           // {
              //  residu = a % b;
              //  a = b;
             //   b = residu;
           // }
           // return a;
       // }

        private void Normalitza()
        {
            int divisor;
            if (this.den < 0)
            {
                this.den = -this.den;
                this.num = -this.num;
            }
            divisor = MCD(this);
            this.num = this.num / divisor;
            this.den = this.den / divisor;
        }

        public void Mostra(int opcio)
        {
            switch (opcio)
            {
                case 1:
                    Racional simplificat = new Racional(this);
                    simplificat.Normalitza();
                    Console.WriteLine("El racional és " + this.num + "/" + this.den + " normalitzat queda " + simplificat.num + "/" + simplificat.den);
                    Console.ReadLine();
                    break;

                case 2:
                    Console.WriteLine("El racional no normalitzat queda " + num + "/" + den);
                    Console.ReadLine();
                    break;
            }
        }
        public  static Racional operator +(Racional fraccio,Racional fraccio2)
        {
            Racional R3 = new Racional();
            R3.num = fraccio.num + fraccio2.num;
            R3.den = fraccio.den + fraccio2.den;
            if (R3.den == 0)
            {
                Console.WriteLine("No es pot calcular perquè el denominador és igual a 0");
            }
            return R3;
        }

        public static  Racional operator *(Racional fraccio,Racional fraccio2)
        {
            Racional R3 = new Racional();
            R3.num = fraccio.num * fraccio2.den + fraccio.den * fraccio2.num;
            R3.den = fraccio.den * fraccio2.den;
            if (R3.den == 0)
            {
                Console.WriteLine("No es pot calcular");
            }
            return R3;
        }
        public static bool operator !=(Racional r1, Racional r2)
        {
            r1.Normalitza();
            r2.Normalitza();
            return (r1.num != r2.num && r1.den != r2.den);
        }
        public static bool operator ==(Racional r1, Racional r2)
        {
            r1.Normalitza();
            r2.Normalitza();
            return (r1.num == r2.num && r1.den == r2.den);
        }

        public static bool operator >(Racional R1, Racional R2)
        {
            R1.Normalitza();
            R2.Normalitza();
            return (R1.num > R2.num && R1.den > R2.den);
        }
        public static int operator %(Racional R1,Racional R2)
        {
            R1.Normalitza();
            R2.Normalitza();
            return (R1 % R2);
        }

        public static bool operator <(Racional R1, Racional R2)
        {
            R1.Normalitza();
            R2.Normalitza();
            return (R1.num < R2.num && R1.den < R2.den);
        }
        static public Racional operator ++(Racional R1)
        {
            Racional R2 = new Racional();
            R1 = R1.Suma(R2);
            return R1;
        }

        static public Racional operator --(Racional R1)
        {
            Racional R2 = new Racional();
            R1 = R1.Resta(R2);
            return R1;
        }

        public override string ToString()
        {
            return num + "/" + den;
        }

    }
}
